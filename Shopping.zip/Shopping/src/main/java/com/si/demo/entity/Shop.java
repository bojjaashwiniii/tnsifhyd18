package com.si.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Shop {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
	private Long shopid;
private String shopname;
public Long getid(){
	return shopid;
}
public Shop() {
	
}

public Shop(Long shopid, String shopname) {

	this.shopid = shopid;
	this.shopname = shopname;
}

public Long getShopid() {
	return shopid;
}

public void setShopid(Long shopid) {
	this.shopid = shopid;
}

public String getShopname() {
	return shopname;
}

public void setShopname(String shopname) {
	this.shopname = shopname;
}

@Override
public String toString() {
	return "Shop [shopid=" + shopid + ", shopname=" + shopname + "]";
}

}
