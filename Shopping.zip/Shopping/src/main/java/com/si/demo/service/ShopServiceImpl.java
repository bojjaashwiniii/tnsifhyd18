package com.si.demo.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.si.demo.entity.Shop;
import com.si.demo.repository.ShopRepository;

@Service
public class ShopServiceImpl implements ShopService{
@Autowired
ShopRepository s2;


@Override
public Shop saveShop(Shop shop) {
	// TODO Auto-generated method stub
	return s2.save(shop);
}

@Override
public List<Shop> fetchShopList() {
	// TODO Auto-generated method stub
	return s2.findAll();
}

@Override
public Shop fetchShopById(Long id) {
	// TODO Auto-generated method stub
	return s2.findById(id).get();
}

@Override
public void deleteShopById(Long id) {
	// TODO Auto-generated method stub
	 s2.deleteById(id);
}

@Override
public Shop updateshop(Long shopId, Shop shop) {
	// TODO Auto-generated method stub
	Shop shopDB= s2.findById(shopId).get();

    if(Objects.nonNull(shop.getShopname()) &&
    !"".equalsIgnoreCase(shop.getShopname())) {
        shopDB.setShopname(shop.getShopname());
    }

    
	return s2.save(shopDB);
}

}