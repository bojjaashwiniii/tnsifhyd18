package com.si.demo.service;

import java.util.List;

import com.si.demo.entity.Shop;

public interface ShopService {

	void deleteShopById(Long id);

	Shop saveShop(Shop shop);

	List<Shop> fetchShopList();

	Shop fetchShopById(Long id);

	Shop updateshop(Long shopId, Shop shop);

}


