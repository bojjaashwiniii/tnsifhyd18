package com.day2;

public class prgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ternary operator
		int age = 22;
		String a = "Allowed to vote";
		String b = "Not allowed to vote";
		String accessallowed = (age > 18) ? a : b;
		System.out.println(accessallowed);
		int x;
		x = (10>9) ? 1 : 0;
		System.out.println(x);
	}

	}


	


