package com.day2;

import java.util.Scanner;

public class prgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Scanner input = new Scanner(System.in);
		    System.out.println("Enter an integer: ");
		    // reads an int value
		    int data1 = input.nextInt();
		    System.out.println("Using nextInt(): " + data1);
		    input.close();
		  }



	}


