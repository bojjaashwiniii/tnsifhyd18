package com.day2;

public class prgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//increment and decrement
		
		 int x = 1+2;  
	        String s = "Hello" + "world";  
	        System.out.println(x);  
	        System.out.println(s); 
        int y= 1;  
        int z = 12 - x;  
        System.out.println(z);  
        int a= 1;  
        int b = 12 * 2;  
        System.out.println(b);  
        int c= 1;  
        int d= 12 / 2;  
        System.out.println(d);  
        int e= 1;  
        int f = 12 / 2;  
        System.out.println(f);  
    	int g = 10;
        System.out.println(g++);
    	int h= 10;
        System.out.println(++h);
    	int i = 10;
        System.out.println(i--);
    	int j= 10;
		System.out.println(--j);
}


}

   

    

    


    


	


