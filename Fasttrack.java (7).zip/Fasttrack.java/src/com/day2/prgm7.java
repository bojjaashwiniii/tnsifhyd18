package com.day2;

public class prgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// assignment operator
		int x=5;
		x+= 5;
		 x-= 5;
		System.out.println(x);
		int z= 5;
		z*= 5;
		System.out.println(z);
		int a = 5;
		a/= 5;
		System.out.println(a);
		int b= 5;
		 b%= 5;
		System.out.println(b);
	}

	}
	

	
	


	


