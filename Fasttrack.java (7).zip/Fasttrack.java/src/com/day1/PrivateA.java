package com.day1;

public class PrivateA {
	
	void display()
	{
	System.out.println("TNS Sessions");
	}
}
