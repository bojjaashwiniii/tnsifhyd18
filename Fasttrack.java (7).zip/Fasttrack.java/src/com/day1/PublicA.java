package com.day1;

public class PublicA {
	
	public void display() {
		System.out.println("TNS Sessions");
	}

}
